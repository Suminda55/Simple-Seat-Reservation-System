import java.util.Scanner;

public class SeatReservationSystem {
    
    private static final int ROWS = 5;
    private static final int COLS = 8;
    
    private static String[][] seats = new String[ROWS][COLS];

    public static void main(String[] args) {
        initializeSeats();
        Scanner sc = new Scanner(System.in);

        while (true) {
            displaySeatingChart();
            
            System.out.print("\nEnter seat number to reserve (1-40) or 0 to quit: ");
            int seatNumber;
            
            try {
                seatNumber = Integer.parseInt(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a number.");
                continue;
            }
         
            if (seatNumber == 0) {
                System.out.println("Thank you for using the seat reservation system. Goodbye!");
                break;
            }

            if (seatNumber < 1 || seatNumber > 40) {
                System.out.println("Error: Seat number must be between 1 and 40.");
                continue;
            }

            int row = (seatNumber - 1) / COLS;     
            int col = (seatNumber - 1) % COLS;     
           
            if (seats[row][col].equals("X")) {
                System.out.println("Sorry, seat " + seatNumber + " is already reserved.");
            } else {
               
                seats[row][col] = "X";
                System.out.println("Seat " + seatNumber + " successfully reserved!");
            }
        }
        
        sc.close();
    }

    private static void initializeSeats() {
        int seatNum = 1;
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                seats[i][j] = String.format("%2d", seatNum); 
                seatNum++;
            }
        }
    }

    private static void displaySeatingChart() {
        System.out.println("\n          === CURRENT SEATING CHART ===\n");
        System.out.println("          SCREEN THIS SIDE");
        System.out.println("   --------------------------------");

        for (int i = 0; i < ROWS; i++) {
            System.out.print("Row " + (i + 1) + " ");
            if (i + 1 < 10) System.out.print(" "); 

            for (int j = 0; j < COLS; j++) {
                System.out.print(" " + seats[i][j] + " ");
            }
            System.out.println();
        }

        System.out.println("   --------------------------------");
        System.out.println("Legend: Numbers = Available,  X  = Reserved\n");
    }
}